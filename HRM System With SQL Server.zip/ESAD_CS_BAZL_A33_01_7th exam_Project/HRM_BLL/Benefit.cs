﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRM_BLL
{
    public class Benefit
    {
        public int Benefit_ID { get; set; }
        public string Benefit_Type { get; set; }
    }
}
