﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRM_BLL
{
   public class Employee_Type
    {
        public int EmployeeType_ID { get; set; }
        public string Employee_Types { get; set; }
    }
}
